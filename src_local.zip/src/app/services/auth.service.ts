import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { map, tap } from 'rxjs/operators';
import { UserCredentialsModel } from '../models/user-credentials.model';
import { AuthApiResponseModel } from '../models/auth-api-response.model';
import { MeModel } from '../models/me.model';
import { MeResponseModel } from '../models/me-response.model';
import { environment } from 'src/environments/environment';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private _isUserLoggedInSubject: BehaviorSubject<UserCredentialsModel | null> =
    new BehaviorSubject<UserCredentialsModel | null>(
      localStorage.getItem('accessToken')
        ? {
            accessToken: localStorage.getItem('accessToken'),
            id: localStorage.getItem('id'),
          }
        : null
    );
  public readonly isUserLoggedIn$: Observable<UserCredentialsModel | null> =
    this._isUserLoggedInSubject.asObservable();

  constructor(private _httpClient: HttpClient) {}
  //nie providowałem storage bo mi się cała apka wykrzaczała tak jak innym zresztą (wątek na slacku).
  //Fajnie by było wyjaśnic co źle robimy :)

  private logInUser(credentials: UserCredentialsModel): void {
    this._isUserLoggedInSubject.next(credentials);
    localStorage.setItem('id', credentials.id!);
    localStorage.setItem('accessToken', credentials.accessToken!);
  }

  public logOutUser(): void {
    this._isUserLoggedInSubject.next(null);
    localStorage.clear();
  }

  public onLoginCheckCredentials(login: {
    email: string;
    password: string;
  }): Observable<UserCredentialsModel> {
    return this._httpClient
      .post<AuthApiResponseModel>(environment.apiUrl + '/auth/login', {
        data: {
          email: login.email,
          password: login.password,
        },
      })
      .pipe(
        map((response) => ({
          id: response.data.id,
          accessToken: response.data.accessToken,
        })),
        tap((data) => this.logInUser(data))
      );
  }

  getMe(): Observable<MeModel> {
    return this._httpClient
      .get<MeResponseModel>(environment.apiUrl + '/auth/me')
      .pipe(
        map((response) => ({
          id: response.data.user.context.user_id,
          email: response.data.user.context.email,
        }))
      );
  }
}
