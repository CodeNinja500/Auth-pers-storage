export interface MeModel {
  readonly id: string;
  readonly email: string;
}
