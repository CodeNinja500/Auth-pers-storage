export interface UserCredentialsModel {
  readonly accessToken: string | null;
  readonly id: string | null;
}
