import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { map, tap } from 'rxjs/operators';
import { UserCredentialsModel } from '../models/user-credentials.model';
import { AuthApiResponseModel } from '../models/auth-api-response.model';
import { environment } from 'src/environments/environment';
import { CookieService } from 'ngx-cookie-service';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private _isUserLoggedInSubject: BehaviorSubject<UserCredentialsModel | null> =
    new BehaviorSubject<UserCredentialsModel | null>(
      localStorage.getItem('accessToken')
        ? {
            //Wiem, trzeba zrobić żeby tylko w prive podmienić local na cookies a nie zmieniać w kilku miejscach...
            //nie wiem jak obejść wysypywanie się apki więc na razie zrobiłem tak. Do poprawienia jak rozkminimy gdzie leży problem

            // accessToken: localStorage.getItem('accessToken'),
            // id: localStorage.getItem('id'),
            accessToken: this._cookieService.get('accessToken'),
            id: this._cookieService.get('id'),
          }
        : null
    );
  public readonly isUserLoggedIn$: Observable<UserCredentialsModel | null> =
    this._isUserLoggedInSubject.asObservable();

  constructor(
    private _httpClient: HttpClient,
    private _cookieService: CookieService
  ) {}
  //nie providowałem storage bo mi się cała apka wykrzaczała tak jak innym zresztą (wątek na slacku).
  //Fajnie by było wyjaśnic co źle robimy :)

  private logInUser(credentials: UserCredentialsModel): void {
    this._isUserLoggedInSubject.next(credentials);

    // localStorage.setItem('id', credentials.id!);
    // localStorage.setItem('accessToken', credentials.accessToken!);

    this._cookieService.set('id', credentials.id!);
    this._cookieService.set('accessToken', credentials.accessToken!);
  }

  public logOutUser(): void {
    this._isUserLoggedInSubject.next(null);
    localStorage.clear();

    this._cookieService.deleteAll();
  }

  public onLoginCheckCredentials(login: {
    email: string;
    password: string;
  }): Observable<UserCredentialsModel> {
    return this._httpClient
      .post<AuthApiResponseModel>(environment.apiUrl + '/auth/login', {
        data: {
          email: login.email,
          password: login.password,
        },
      })
      .pipe(
        map((response) => ({
          id: response.data.id,
          accessToken: response.data.accessToken,
        })),
        tap((data) => this.logInUser(data))
      );
  }
}
